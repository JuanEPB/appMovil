import React from "react";
import { View, Text, Switch, StyleSheet } from "react-native";
import { useTheme } from "../context/ThemeContext";
import { Ionicons } from "@expo/vector-icons";

export const SettingsScreen = () =>{
  const { theme, toggleTheme } = useTheme();

  const isDarkMode = theme.mode === "dark";

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.colors.background },
      ]}
    >
      <Text style={[styles.header, { color: theme.colors.primary }]}>
        Ajustes
      </Text>

      {/* Sección de tema */}
      <View
        style={[
          styles.optionCard,
          { backgroundColor: theme.colors.card, borderColor: theme.colors.border },
        ]}
      >
        <View style={styles.optionRow}>
          <Ionicons
            name={isDarkMode ? "moon" : "sunny"}
            size={28}
            color={theme.colors.primary}
          />
          <Text style={[styles.optionText, { color: theme.colors.text }]}>
            Modo {isDarkMode ? "oscuro" : "claro"}
          </Text>

          <Switch
            value={isDarkMode}
            onValueChange={toggleTheme}
            thumbColor={isDarkMode ? theme.colors.primary : "#f4f3f4"}
            trackColor={{ false: "#d1d1d1", true: "#90CAF9" }}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 26,
    fontWeight: "800",
    marginBottom: 24,
  },
  optionCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  optionRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  optionText: {
    fontSize: 18,
    fontWeight: "600",
    flex: 1,
    marginLeft: 10,
  },
});
