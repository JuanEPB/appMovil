export const appTheme =  {
  colors: {
    primary: "#007bff",   // azul corporativo
    success: "#28a745",   // stock OK
    danger: "#dc3545",    // stock crítico
    warning: "#ffc107",   // por caducar
    background: "#f8f9fa",
    text: "#343a40",
    card: "#ffffff",
    muted: "#6c757d",
  },
  spacing: {
    sm: 8,
    md: 16,
    lg: 24,
  },
  radius: {
    sm: 6,
    md: 12,
    lg: 20,
  },
};
export const colors = {
  // 🎯 Colores principales
  primary: "#1A237E",      // Azul marino (confianza, salud)
  secondary: "#2E7D32",    // Verde esmeralda (eficiencia, farmacia)
  accent: "#00BFA6",       // Verde agua para botones secundarios

  // ⚠️ Estados
  success: "#2E7D32",      // Éxito
  warning: "#dfcc25ff",      // Advertencia (por caducar)
  danger: "#D32F2F",       // Error / caducado

  // 🩺 Fondo y texto
  background: "#F5F7FB",   // Fondo general de pantallas
  card: "#FFFFFF",         // Fondo de tarjetas
  border: "#E0E0E0",       // Borde o separadores
  text: "#212121",         // Texto principal
  textMuted: "#757575",    // Texto secundario o placeholder

  // 🌙 Modo oscuro (opcional)
  dark: {
    background: "#0D1117",
    card: "#161B22",
    text: "#E6EDF3",
    textMuted: "#8B949E",
    border: "#30363D",
  },
};

export const lightTheme = {
  mode: "light",
  colors: {
    primary: "#1A237E",
    secondary: "#2E7D32",
    background: "#F5F7FB",
    card: "#FFFFFF",
    text: "#212121",
    textMuted: "#757575",
    border: "#E0E0E0",
    success: "#2E7D32",
    warning: "#FFC107",
    danger: "#D32F2F",
  },
};

export const darkTheme = {
  mode: "dark",
  colors: {
    primary: "#90CAF9",
    secondary: "#A5D6A7",
    background: "#0D1117",
    card: "#161B22",
    text: "#E6EDF3",
    textMuted: "#8B949E",
    border: "#30363D",
    success: "#81C784",
    warning: "#FFD54F",
    danger: "#EF9A9A",
  },
};
