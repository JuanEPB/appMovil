import axios from 'axios';

export const apiPharma = axios.create({
    baseURL: 'http://192.168.100.11:3000',
    headers: {
        'Content-Type': 'application/json',
    },
});

export const getMedicamentos = async () => {
  const res = await apiPharma.get("/api/medicamentos/all");
  return res.data;
};

export const getMedicamentoById = async (id: number) => {
  const res = await apiPharma.get(`/api/medicamentos/${id}`);
  console.log(res.data);
  return res.data;
};

export const createMedicamento = async (data: any) => {
  const res = await apiPharma.post("/api/medicamentos/create", data);
  return res.data;
};

export const getMedicamentosStats = async () => {
  const res = await apiPharma.get("/api/medicamentos/stats");
  return res.data;
};
