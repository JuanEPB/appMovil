import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {DashboardScreen} from "../screens/DashboardScreen";
import {ChatScreen} from "../screens/ChatScreen";
import {DocumentsScreen} from "../screens/DocumentsScreen";
import {ProfileScreen} from "../screens/ProfileScreen";
import {SettingsScreen} from "../screens/SettingsScreen";
import { Ionicons } from "@expo/vector-icons"; // 👈 Importamos íconos
import { colors } from "../themes/appTheme";
import { useTheme } from "../context/ThemeContext";

const Tab = createBottomTabNavigator();

export const TabNavigator = () => {
  const { theme } = useTheme();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.text,
        tabBarStyle: {
          backgroundColor: theme.colors.card,
          borderTopWidth: 0.5,
          borderTopColor: "#e0e0e0",
          height: 60,
          paddingBottom: 6,
        },
        // 👇 Aquí configuramos el icono dinámicamente
        tabBarIcon: ({ color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap = "home";

          if (route.name === "Dashboard") iconName = "home";
          else if (route.name === "Documentos") iconName = "document-text";
          else if (route.name === "Chat") iconName = "chatbubble-ellipses";
          else if (route.name === "Perfil") iconName = "person-circle";
          else if (route.name === "Ajustes") iconName = "settings";

          return <Ionicons name={iconName} size={24} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Documentos" component={DocumentsScreen} />
      <Tab.Screen name="Chat" component={ChatScreen} />
      <Tab.Screen name="Perfil" component={ProfileScreen} />
      <Tab.Screen name="Ajustes" component={SettingsScreen} />
    </Tab.Navigator>
  );
}
