import React, { useMemo, useRef, useEffect } from "react";
import { View, Text, StyleSheet, Animated, Easing } from "react-native";
import { useTheme } from "../context/ThemeContext";
import { FadeSlideIn as Fade } from "../components/FadeSlideIn";

export const ProfileScreen = () => {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);

  const scale = useRef(new Animated.Value(0.95)).current;
  useEffect(() => {
    Animated.timing(scale, { toValue: 1, duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [scale]);

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.avatar, { transform: [{ scale }] }]} />
      <Fade><Text style={styles.name}>Usuario</Text></Fade>
      <Fade delay={100}><Text style={styles.email}>usuario@correo.com</Text></Fade>
    </View>
  );
};

const getStyles = (theme:any)=> StyleSheet.create({
  container: { flex:1, alignItems:"center", justifyContent:"center", backgroundColor: theme.colors.background },
  avatar: { width: 96, height: 96, borderRadius: 48, backgroundColor: theme.colors.card, marginBottom: 12 },
  name: { color: theme.colors.text, fontWeight:"800", fontSize: 18 },
  email: { color: theme.colors.textMuted },
});
