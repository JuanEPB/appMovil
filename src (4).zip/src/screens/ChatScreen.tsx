import React, { useMemo, useState } from "react";
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList } from "react-native";
import { useTheme } from "../context/ThemeContext";
import { FadeSlideIn as Fade } from "../components/FadeSlideIn";

type Msg = { id: string; text: string; from: "user" | "bot" };

export const ChatScreen = () => {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const [msgs, setMsgs] = useState<Msg[]>([{ id: "1", text: "Hola, ¿en qué puedo ayudarte?", from: "bot" }]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    const m: Msg = { id: String(Date.now()), text: input.trim(), from: "user" };
    setMsgs((prev) => [...prev, m, { id: String(Date.now() + 1), text: "Recibido ✅", from: "bot" }]);
    setInput("");
  };

  const renderItem = ({ item }: { item: Msg }) => (
    <Fade>
      <View
        style={[
          styles.bubble,
          item.from === "user" ? styles.right : styles.left,
          { backgroundColor: item.from === "user" ? theme.colors.primary : theme.colors.card },
        ]}
      >
        <Text style={{ color: item.from === "user" ? "#fff" : theme.colors.text }}>{item.text}</Text>
      </View>
    </Fade>
  );

  return (
    <View style={styles.container}>
      <FlatList data={msgs} keyExtractor={(it) => it.id} renderItem={renderItem} contentContainerStyle={{ padding: 12 }} />
      <View style={styles.inputRow}>
        <TextInput value={input} onChangeText={setInput} style={styles.input} placeholder="Escribe un mensaje..." placeholderTextColor={theme.colors.textMuted} />
        <TouchableOpacity onPress={send} style={[styles.sendBtn, { backgroundColor: theme.colors.primary }]}>
          <Text style={{ color: "#fff", fontWeight: "700" }}>Enviar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const getStyles = (theme:any) => StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.background },
  bubble: { maxWidth: "75%", padding: 10, borderRadius: 14, marginVertical: 6 },
  left: { alignSelf: "flex-start" },
  right: { alignSelf: "flex-end" },
  inputRow: { flexDirection: "row", padding: 10, gap: 8, backgroundColor: theme.colors.card },
  input: { flex: 1, borderRadius: 12, borderWidth: 1, borderColor: theme.colors.border, paddingHorizontal: 12, color: theme.colors.text },
  sendBtn: { paddingHorizontal: 16, borderRadius: 12, justifyContent: "center" },
});
