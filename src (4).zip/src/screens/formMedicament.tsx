import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Dimensions,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { apiPharma } from "../api/apiPharma";
import { useTheme } from "../context/ThemeContext";
import { SuccessModal } from "../components/SuccessModal";
import { FadeSlideIn as Fade } from "../components/FadeSlideIn";
import { Categoria, Proveedor } from "../interfaces/interface";
import { Picker } from "@react-native-picker/picker";
import DateTimePicker from "@react-native-community/datetimepicker";

const h = Dimensions.get("window").height ;
const w = Dimensions.get("window").width;

export const formMedicament = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const styles = useMemo(() => getStyles(theme), [theme]);

  // Estados del formulario
  const [nombre, setNombre] = useState("");
  const [lote, setLote] = useState("");
  const [stock, setStock] = useState("");
  const [caducidad, setCaducidad] = useState("");

  // Listas para selects
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [proveedores, setProveedores] = useState<Proveedor[]>([]);

  // Seleccionados
  const [categoriaId, setCategoriaId] = useState<number | null>(null);
  const [proveedorId, setProveedorId] = useState<number | null>(null);

  const [saving, setSaving] = useState(false);
  const [ok, setOk] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);


  // Cargar categorías y proveedores desde API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = await AsyncStorage.getItem("token");
        const headers = { Authorization: `Bearer ${token}` };

        const [catRes, provRes] = await Promise.all([
          apiPharma.get("/api/categorias/all", { headers }),
          apiPharma.get("/api/proveedores/all", { headers }),
        ]);

        setCategorias(catRes.data || []);
        setProveedores(provRes.data || []);
      } catch (error) {
        console.error("Error cargando datos:", error);
      }
    };

    fetchData();
  }, []);

  const submit = async () => {
    try {
      setSaving(true);
      const token = await AsyncStorage.getItem("token");
      if (!token) throw new Error("No token");

      const payload = {
        nombre,
        lote,
        stock: Number(stock || 0),
        caducidad,
        categoriaId,
        proveedorId,
      };

      await apiPharma.post("/api/medicamentos/create", payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setOk(true);
      setTimeout(() => {
        setOk(false);
        navigation.goBack();
      }, 1600);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, height: h, width: w }}

      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={[styles.container]}
        showsVerticalScrollIndicator={false}

      >
        <Fade>
          <Text style={styles.title}>Agregar Medicamento</Text>
        </Fade>

        {/* ---------- CAMPOS DE TEXTO ---------- */}
        <Fade delay={80}>
          <View style={styles.field}>
            <Text style={styles.label}>Nombre</Text>
            <TextInput
              value={nombre}
              onChangeText={setNombre}
              style={styles.input}
              placeholder="Paracetamol 500mg"
              placeholderTextColor={theme.colors.textMuted}
            />
          </View>
        </Fade>

        <Fade delay={120}>
          <View style={styles.field}>
            <Text style={styles.label}>Lote</Text>
            <TextInput
              value={lote}
              onChangeText={setLote}
              style={styles.input}
              placeholder="ABC12345"
              placeholderTextColor={theme.colors.textMuted}
            />
          </View>
        </Fade>

        <Fade delay={160}>
          <View style={styles.field}>
            <Text style={styles.label}>Stock</Text>
            <TextInput
              value={stock}
              onChangeText={setStock}
              keyboardType="numeric"
              style={styles.input}
              placeholder="10"
              placeholderTextColor={theme.colors.textMuted}
            />
          </View>
        </Fade>

        <Fade delay={200}>
  <View style={styles.field}>
    <Text style={styles.label}>Caducidad</Text>

    <TouchableOpacity
      onPress={() => setShowDatePicker(true)}
      activeOpacity={0.8}
    >
      <TextInput
        value={caducidad}
        style={[styles.input, { color: caducidad ? theme.colors.text : theme.colors.textMuted }]}
        placeholder="Seleccione la fecha de caducidad"
        placeholderTextColor={theme.colors.textMuted}
        editable={false}
        pointerEvents="none"
      />
    </TouchableOpacity>

    {showDatePicker && (
      <DateTimePicker
        value={caducidad ? new Date(caducidad) : new Date()}
        mode="date"
        display={Platform.OS === "ios" ? "spinner" : "calendar"}
        onChange={(event, selectedDate) => {
          setShowDatePicker(false);
          if (selectedDate) {
            // Format date as yyyy-MM-dd
            const formatted = selectedDate.toISOString().split("T")[0];
            setCaducidad(formatted);
          }
        }}
        minimumDate={new Date()} // evita fechas pasadas
      />
    )}
  </View>
</Fade>


        {/* ---------- SELECT DE CATEGORÍA ---------- */}
        <Fade delay={240}>
          <View style={styles.field}>
            <Text style={styles.label}>Categoría</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={categoriaId}
                onValueChange={(value) => setCategoriaId(value)}
                style={styles.picker}
              >
                <Picker.Item
                  label="Seleccione una categoría..."
                  value={null}
                  color={theme.colors.textMuted}
                />
                {categorias.map((cat) => (
                  <Picker.Item
                    key={cat.id}
                    label={cat.nombre}
                    value={cat.id}
                    color={theme.colors.text}
                  />
                ))}
              </Picker>
            </View>
          </View>
        </Fade>

        {/* ---------- SELECT DE PROVEEDOR ---------- */}
        <Fade delay={280}>
          <View style={styles.field}>
            <Text style={styles.label}>Proveedor</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={proveedorId}
                onValueChange={(value) => setProveedorId(value)}
                style={styles.picker}
              >
                <Picker.Item
                  label="Seleccione un proveedor..."
                  value={null}
                  color={theme.colors.textMuted}
                />
                {proveedores.map((prov) => (
                  <Picker.Item
                    key={prov.id}
                    label={prov.nombre}
                    value={prov.id}
                    color={theme.colors.text}
                  />
                ))}
              </Picker>
            </View>
          </View>
        </Fade>

        {/* ---------- BOTONES ---------- */}
        <Fade delay={320}>
          <TouchableOpacity
            disabled={saving}
            onPress={submit}
            style={[
              styles.button,
              {
                backgroundColor: theme.colors.primary,
                opacity: saving ? 0.6 : 1,
              },
            ]}
          >
            <Text style={styles.buttonText}>
              {saving ? "Guardando..." : "Guardar"}
            </Text>
          </TouchableOpacity>
        </Fade>

        <Fade delay={340}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={[styles.button, { backgroundColor: theme.colors.danger }]}
          >
            <Text style={styles.buttonText}>Cancelar</Text>
          </TouchableOpacity>
        </Fade>
      </ScrollView>

      <SuccessModal
        visible={ok}
        title="¡Guardado!"
        message="El medicamento se registró correctamente."
      />
    </KeyboardAvoidingView>
  );
};

const getStyles = (theme: any) =>
  StyleSheet.create({
    container: {
      padding: 18,
      paddingTop: 28,
      backgroundColor: theme.colors.background,
      flexGrow: 1,
    },
    title: {
      fontSize: 22,
      fontWeight: "800",
      color: theme.colors.primary,
      textAlign: "center",
      marginBottom: 18,
    },
    field: { marginBottom: 12 },
    label: { fontSize: 13, color: theme.colors.textMuted, marginBottom: 6 },
    input: {
      backgroundColor: theme.colors.card,
      borderWidth: 1,
      borderColor: theme.colors.border,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderRadius: 12,
      color: theme.colors.text,
    },
    pickerContainer: {
      backgroundColor: theme.colors.card,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: theme.colors.border,
      overflow: "hidden",
    },
    picker: {
      color: theme.colors.text,
      height: 48,
    },
    button: {
      marginTop: 8,
      alignSelf: "center",
      paddingHorizontal: 20,
      paddingVertical: 12,
      borderRadius: 14,
      shadowColor: "#000",
      shadowOpacity: 0.08,
      shadowRadius: 6,
      elevation: 2,
    },
    buttonText: { color: "#fff", fontWeight: "700" },
  });
