import React from "react";
import { createDrawerNavigator } from "@react-navigation/drawer";
import {DashboardScreen} from "../screens/DashboardScreen";
import { SettingsScreen } from "../screens/SettingsScreen";
import { ChatScreen } from "../screens/ChatScreen";
import { ProfileScreen } from "../screens/ProfileScreen";
import { DocumentsScreen } from "../screens/DocumentsScreen";
import { Sidebar } from "../components/Sidebar";
import { MedicamentosScreen } from "../screens/MedicamentosScreen";
import { formMedicament } from '../screens/formMedicament';

export type RootDrawerParamList = {
  Dashboard: undefined;
  Documents: undefined;
  Chat: undefined;
  Profile: undefined;
  Settings: undefined;
  Medicamentos: undefined;
  formMedicament: undefined;
};

const Drawer = createDrawerNavigator<RootDrawerParamList>();

export const DrawerNavigator = () => {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: false,
        headerStyle: { backgroundColor: "#fff" },
        headerTintColor: "#1A237E",
        headerTitleAlign: "center",
      }}
      drawerContent={(props) => <Sidebar {...props} />}
    >
      <Drawer.Screen name="Dashboard" component={DashboardScreen} />
      <Drawer.Screen name="Documents" component={DocumentsScreen} />
      <Drawer.Screen name="Chat" component={ChatScreen} />
      <Drawer.Screen name="Profile" component={ProfileScreen} />
      <Drawer.Screen name="Settings" component={SettingsScreen} />
      <Drawer.Screen name="Medicamentos" component={MedicamentosScreen} />
      <Drawer.Screen name="formMedicament" component={formMedicament}/>

    </Drawer.Navigator>
  );
};
