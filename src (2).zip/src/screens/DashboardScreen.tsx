import React from "react";
import {
  View,
  Text,
  ActivityIndicator,
  Dimensions,
  StyleSheet,
  ScrollView,
  SafeAreaView,
} from "react-native";
import { BarChart, PieChart } from "react-native-chart-kit";
import { useStats } from "../hooks/useStats";
import { colors } from "../themes/appTheme";
import { useTheme } from "../context/ThemeContext";

const screenWidth = Dimensions.get("window").width - 32;

export const DashboardScreen = () => {
  const { stats, loading, error } = useStats();

  if (loading) return <ActivityIndicator size="large" color={colors.primary} />;
  if (error) return <Text style={{ color: colors.danger }}>{error}</Text>;
  if (!stats) return <Text>No hay datos disponibles</Text>;

  const categorias = Object.entries(stats.porCategoria).map(([key, value], i) => ({
    name: key,
    population: value,
    color: [colors.primary, colors.success, colors.warning, "#00897B", "#5E35B1"][i % 5],
    legendFontColor: "#333",
    legendFontSize: 13,
  }));


  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        style={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 30 }}
      >
        {/* 🩺 Título */}
        <Text style={styles.title}>Panel de Control</Text>
        <Text style={styles.subtitle}>Gestión inteligente del inventario</Text>

        {/* 🔹 Tarjetas resumen */}
        <View style={styles.cardsRow}>
          <View style={[styles.card, { backgroundColor: "#E8EAF6" }]}>
            <Text style={styles.cardTitle}>Medicamentos Totales</Text>
            <Text style={[styles.cardValue, { color: colors.primary }]}>{stats.total}</Text>
          </View>

          <View style={[styles.card, { backgroundColor: "#FFF8E1" }]}>
            <Text style={styles.cardTitle}>Por Caducar</Text>
            <Text style={[styles.cardValue, { color: colors.warning }]}>{stats.porCaducar}</Text>
          </View>

          <View style={[styles.card, { backgroundColor: "#FFEBEE" }]}>
            <Text style={styles.cardTitle}>Caducados</Text>
            <Text style={[styles.cardValue, { color: colors.danger }]}>{stats.caducados}</Text>
          </View>
        </View>

        {/* 📊 Gráfica de pastel */}
        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Distribución por Categoría</Text>
          <PieChart
            data={categorias}
            width={screenWidth * 0.9}
            height={220}
            accessor={"population"}
            backgroundColor={"transparent"}
            paddingLeft={"80"}
            hasLegend={false}
            chartConfig={chartConfig}
            center={[0, 0]}
          />
           <View style={styles.legendContainer}>
    {categorias.map((item, i) => (
      <View key={i} style={styles.legendItem}>
        <View style={[styles.legendColor, { backgroundColor: item.color }]} />
        <Text style={styles.legendText}>
          {item.population} {item.name}
        </Text>
      </View>
    ))}
  </View>
        </View>

        {/* 📈 Gráfica de barras */}
        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Resumen General</Text>
          <BarChart
            data={{
              labels: ["Total", "Por Caducar", "Caducados"],
              datasets: [{ data: [stats.total, stats.porCaducar, stats.caducados] }],
            }}
            width={screenWidth}
            height={220}
            yAxisLabel=""
            yAxisSuffix=""
            chartConfig={chartConfig}
            style={styles.barChart}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const { theme } = useTheme();

const chartConfig = {
  backgroundGradientFrom: theme.colors.card,
  backgroundGradientTo: theme.colors.card,
  decimalPlaces: 0,
  color: (opacity = 1) => `${theme.colors.primary}${Math.floor(opacity * 255).toString(16)}`,
  labelColor: () => theme.colors.text,
};

const styles = StyleSheet.create({
  safeArea: {
    top: 50,
    flex: 1,
    backgroundColor: "#F9FAFB",
  },
  scrollContainer: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    color: colors.primary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 15,
    color: "#666",
    marginBottom: 20,
  },
  cardsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  card: {
    flex: 1,
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 10,
    marginHorizontal: 4,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
    alignItems: "center",
    justifyContent: "center",
  },
  cardTitle: {
    fontSize: 14,
    color: "#444",
    textAlign: "center",
    marginBottom: 6,
  },
  cardValue: {
    fontSize: 28,
    fontWeight: "800",
  },
  chartContainer: {
    marginBottom: 24,
    backgroundColor: "#fff",
    borderRadius: 20,
    paddingVertical: 14,
    paddingHorizontal: 10,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  legendContainer: {
  flexDirection: "row",
  flexWrap: "wrap",
  justifyContent: "center",
  marginTop: 10,
  gap: 8,
},
legendItem: {
  flexDirection: "row",
  alignItems: "center",
  marginHorizontal: 6,
  marginVertical: 4,
},
legendColor: {
  width: 14,
  height: 14,
  borderRadius: 4,
  marginRight: 6,
},
legendText: {
  fontSize: 14,
  color: "#333",
  fontWeight: "500",
},

  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 10,
    color: colors.text,
    textAlign: "center",
  },
  barChart: {
    borderRadius: 16,
    marginVertical: 8,
  },
});
