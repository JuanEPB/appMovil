import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { useAuth } from "../hooks/useAuth";
import { InputField } from "../components/InputField";
import { Button } from "../components/Button";
import { SafeAreaView } from "react-native-safe-area-context";
import { useTheme } from "../context/ThemeContext";

export const LoginScreen = () => {
  const { theme } = useTheme();
  const { login, isLoading, error } = useAuth();
  const [email, setemail] = useState("");
  const [contraseña, setcontraseña] = useState("");

  const handleLogin = async () => {
    await login({ email, contraseña });
    if (error) Alert.alert("Error", error);
  };

  // 🔹 Mientras se carga el tema, muestra loader
  if (!theme || !theme.colors) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#fff",
        }}
      >
        <ActivityIndicator size="large" color="#1A237E" />
      </View>
    );
  }

  // ✅ Usa el theme dinámicamente para los estilos
  const dynamicStyles = styles(theme);

  return (
    <SafeAreaView style={dynamicStyles.container}>
      <View style={dynamicStyles.form}>
        <Text style={dynamicStyles.title}>PharmaControl</Text>

        <InputField
          placeholder="Correo electrónico"
          value={email}
          onChangeText={setemail}
        />
        <InputField
          placeholder="Contraseña"
          value={contraseña}
          onChangeText={setcontraseña}
          secureTextEntry
        />

        <Button
          title={isLoading ? "Ingresando..." : "Iniciar Sesión"}
          onPress={handleLogin}
        />

        <TouchableOpacity>
          <Text style={dynamicStyles.forgot}>¿Olvidaste tu contraseña?</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

// ✅ Stylesheet que depende del theme del contexto
const styles = (theme: any) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.colors.background,
      justifyContent: "center",
      padding: 20,
    },
    form: {
      backgroundColor: theme.colors.card,
      borderRadius: 12,
      padding: 20,
      shadowColor: "#000",
      shadowOpacity: 0.05,
      shadowRadius: 5,
      elevation: 3,
    },
    title: {
      fontSize: 26,
      fontWeight: "bold",
      color: theme.colors.primary,
      textAlign: "center",
      marginBottom: 20,
    },
    forgot: {
      marginTop: 15,
      textAlign: "center",
      color: theme.colors.primary,
      fontWeight: "600",
    },
  });
