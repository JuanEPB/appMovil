
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import WebView from 'react-native-webview';
import { useTheme } from '../context/ThemeContext';

export const DocumentsScreen = () => {
  const { theme } = useTheme();
  const pdfUrl = 'http://www.africau.edu/images/default/sample.pdf';

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Text style={[styles.title, { color: theme.colors.text }]}>Documentos</Text>
      <WebView
        source={{ uri: pdfUrl }}
        style={styles.webview}
        startInLoadingState
        renderError={(errorName) => (
          <View style={styles.errorBox}>
            <Text style={{ color: 'red', fontWeight: 'bold' }}>Error: {errorName}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginVertical: 15 },
  webview: { flex: 1, marginHorizontal: 10, borderRadius: 10 },
  errorBox: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
